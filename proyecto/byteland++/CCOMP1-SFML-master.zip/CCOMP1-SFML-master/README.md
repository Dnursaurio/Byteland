# CMake SFML Project Template

 Repositorio donde se encuentra una plantilla de CMake para que puedan usar la librería de SFML.
